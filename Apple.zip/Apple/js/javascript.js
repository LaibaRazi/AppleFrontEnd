
function fixedNav(){
    document.getElementsByTagName("nav").style.position="sticky";
}
document.getElementsByTagName("nAct").addEventListener("click",open())
function open() {
document.getElementById("nAct").classList.remove("nAct");
    
}
